package codegeneration;

import ast.expressions.*;

public class ValueCGVisitor extends AbstractCGVisitor{

    @Override
    public Object visit(Arithmetic a, Object parameter) {
        return super.visit(a, parameter);
    }

    @Override
    public Object visit(ArrayAccess aa, Object parameter) {
        return super.visit(aa, parameter);
    }

    @Override
    public Object visit(Cast c, Object parameter) {
        return super.visit(c, parameter);
    }

    /**
     *  value[[ CharLiteral: expression -> CHAR_CONSTANT]]()=
     *  <pushb> expression.value
     */
    @Override
    public Object visit(CharLiteral cl, Object parameter) {
        return super.visit(cl, parameter);
    }

    @Override
    public Object visit(Comparison com, Object parameter) {
        return super.visit(com, parameter);
    }

    @Override
    public Object visit(FieldAccess fila, Object parameter) {
        return super.visit(fila, parameter);
    }

    /**
     *  value[[ IntLiteral: expression -> INT_CONSTANT]]()=
     *  <pushi> expression.value
     */
    @Override
    public Object visit(IntLiteral il, Object parameter) {
        return super.visit(il, parameter);
    }

    @Override
    public Object visit(Logical l, Object parameter) {
        return super.visit(l, parameter);
    }

    /**
     *  value[[ RealLiteral: expression -> REAL_CONSTANT]]()=
     *  <pushf> expression.value
     */
    @Override
    public Object visit(RealLiteral rl, Object parameter) {
        return super.visit(rl, parameter);
    }

    @Override
    public Object visit(UnaryMinus um, Object parameter) {
        return super.visit(um, parameter);
    }

    @Override
    public Object visit(UnaryNegation un, Object parameter) {
        return super.visit(un, parameter);
    }

    /**
     * value[[ Variable: expression -> ID ]]()=
     * address[[ expression ]]()
     * <load> expression.type.suffix()
     */
    @Override
    public Object visit(Variable v, Object parameter) {
        return super.visit(v, parameter);
    }
}
