package codegeneration;

import ast.expressions.ArrayAccess;
import ast.expressions.FieldAccess;
import ast.expressions.Variable;

public class AddressCGVisitor extends AbstractCGVisitor{

    /**
     * address[[ Variable: expression -> ID ]]()=
     * if(expression.definition.scope == 0)
     *      <pusha> expression.definition.offset
     * else
     *      <push bp>
     *      <pushi> expression.definition.offset
     *      <addi>
     */
    @Override
    public Object visit(Variable v, Object parameter) {
        return super.visit(v, parameter);
    }

    @Override
    public Object visit(ArrayAccess aa, Object parameter) {
        return super.visit(aa, parameter);
    }

    @Override
    public Object visit(FieldAccess fila, Object parameter) {
        return super.visit(fila, parameter);
    }

}
