package codegeneration;

import ast.Program;
import ast.definitions.FieldDefinition;
import ast.definitions.FunctionDefinition;
import ast.definitions.VariableDefinition;
import ast.statements.*;

public class ExecuteCGVisitor extends AbstractCGVisitor{

    /**
     * execute[[ Program: program -> definition* ]] () =
     * for(Definition definition : definition*)
     *      if(definition instanceof VariableDefinition)
     *          execute[[ definition ]]()
     * <call main>
     * <halt>
     *
     * for(Definition definition : definition*)
     *      if(definition instanceof FunctionDefinition)
     *          execute[[ definition ]]()
     */
    @Override
    public Object visit(Program p, Object parameter) {
        return super.visit(p, parameter);
    }

    @Override
    public Object visit(FunctionDefinition fund, Object parameter) {
        return super.visit(fund, parameter);
    }

    @Override
    public Object visit(VariableDefinition vd, Object parameter) {
        return super.visit(vd, parameter);
    }

    /**
     * Execute[[ Assignment: statement -> expression1 expression2]]()=
     * address[[expression1]]
     * value[[expression2]]
     * <storei>
     */
    @Override
    public Object visit(Assignment ass, Object parameter) {
        return super.visit(ass, parameter);
    }

    @Override
    public Object visit(FunctionInvocation funi, Object parameter) {
        return super.visit(funi, parameter);
    }

    @Override
    public Object visit(IfStatement ifs, Object parameter) {
        return super.visit(ifs, parameter);
    }

    /**
     * execute[[ Read: statement -> expression ]]() =
     * address[[ expression ]]()
     * <in> expression.type.suffix()
     * <store> expression.type.suffix()
     */
    @Override
    public Object visit(Read red, Object parameter) {
        return super.visit(red, parameter);
    }

    @Override
    public Object visit(ReturnStatement rts, Object parameter) {
        return super.visit(rts, parameter);
    }

    @Override
    public Object visit(While whl, Object parameter) {
        return super.visit(whl, parameter);
    }

    /**
     * execute[[ Write: statement -> expression ]]() =
     * address[[ expression ]]()
     * <out> expression.type.suffix()
     */
    @Override
    public Object visit(Write wrt, Object parameter) {
        return super.visit(wrt, parameter);
    }
}
